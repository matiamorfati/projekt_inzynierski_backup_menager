1. Nazwa aplikacji
Task Manager- aplikacja do zapisywania i zarządzania zadaniami.

2. Ogólne działanie programu
Aplikacja pozwala użytkownikowi tworzyć listę zadań, które chce wykonać.

Użytkownik może:
- dodać nowe zadanie,

- wyświetlić listę wszystkich zadań,

- edytować wybrane zadanie,

- usunąć zadanie,

- oznaczyć zadanie jako wykonane.

Każde zadanie ma tytuł, opis, priorytet oraz opcjonalny termin wykonania.
Aplikacja będzie napisana w Pythonie z użyciem Flaska. Dane są zapisywane w SQLite.

3. Główne funkcjonalności

a) Dodawanie nowego zadania

b) Wyświetlanie listy zadań

c) Edycja istniejącego zadania

d) Usuwanie zadania

e) Zmienianie statusu zadania na „wykonane”.

f) Walidacja danych (np. wymagany tytuł)

4. Odpowiedzialność klas i metod

1.Klasa Task

Reprezentuje pojedyncze zadanie. 
Pola: tytuł, opis, priorytet, status, termin wykonania.

Metody:
mark_done() – oznacza zadanie jako wykonane.

update(...) – aktualizuje dane zadania.

2.Klasa TaskValidator

Odpowiada za sprawdzanie poprawności danych.

Metody:
validate_title(title) – sprawdza, czy tytuł nie jest pusty.

validate_priority(priority) – sprawdza, czy priorytet ma poprawną wartość.

validate_due_date(date) – sprawdza, czy data ma prawidłowy format i nie jest z przeszłości.

3.Klasa TaskRepository

Obsługuje zapis i odczyt zadań z bazy danych SQLite.

Metody:

add(task) – zapisuje nowe zadanie.

get(id) – pobiera zadanie po ID.

update(task) – zapisuje zmienione dane zadania.

delete(id) – usuwa zadanie.

list_all() – zwraca listę wszystkich zadań.

4.Klasa TaskService
Zawiera logikę aplikacji.

Metody:
create_task(data) – twozry nowe zadanie

edit_task(id, data) – modyfikuje zadanie

delete_task(id) – usuwa zadanie

mark_done(id) – oznacza zadanie jako wykonane

get_tasks() – zwraca listę wszystkich zadań

5.Klasa WebController
Łączy aplikację z Flaskiem i obsługuje żądania HTTP.

Metody:

index() – wyświetla listę zadań.

create() – obsługuje formularz dodawania zadania.

edit(id) – obsługuje formularz edycji zadania.

delete(id) – usuwa zadanie.

done(id) – oznacza zadanie jako wykonane.