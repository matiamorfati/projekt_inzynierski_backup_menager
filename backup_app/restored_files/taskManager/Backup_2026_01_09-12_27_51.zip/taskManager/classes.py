from dataclasses import dataclass
from datetime import date
from typing import List, Optional


@dataclass
class Task:
    title: str
    description: str
    priority: int
    status: str
    due_date: date

    def mark_done(self):
        "Oznacza zadanie jako wykonane"
        self.status = "done"


    def update(self, title, description, priority, status, due_date):
        "Aktualizuje dane zadania"
        raise NotImplementedError()


class TaskValidator:
    @staticmethod
    def validate_title(title: str):
        "Sprawdza, czy tytuł jest poprawny"
        raise NotImplementedError()

    @staticmethod
    def validate_priority(priority: int):
        "Sprawdza, czy priorytet jest poprawny"
        raise NotImplementedError()

    @staticmethod
    def validate_due_date(due_date):
        "Sprawdza poprawność daty"
        raise NotImplementedError()


class TaskRepository:
    "Obsługuje zapis i odczyt zadań z bazy danych SQLite"

    def add(self, task: Task) -> int:
        raise NotImplementedError()

    def get(self, task_id: int) -> Optional[Task]:
        raise NotImplementedError()

    def update(self, task: Task) -> None:
        raise NotImplementedError()

    def delete(self, task_id: int) -> None:
        raise NotImplementedError()

    def list_all(self) -> List[Task]:
        raise NotImplementedError()


class TaskService:
    "Logika aplikacji Task Manager"

    def __init__(self):
        pass

    def create_task(self, data: dict):
        "Tworzy nowe zadanie"
        raise NotImplementedError()

    def edit_task(self, task: Task, data: dict):
        "Modyfikuje istniejące zadanie"
        raise NotImplementedError()

    def mark_done(self, task: Task):
        "Oznacza zadanie jako wykonane"
        raise NotImplementedError()


class WebController:
    "Warstwa webowa, później będzie spięta z Flaskiem"

    def index(self):
        "Wyświetla listę zadań"
        raise NotImplementedError()

    def create(self):
        "Obsługuje dodawanie zadania"
        raise NotImplementedError()

    def edit(self, task_id: int):
        "Obsługuje edycję zadania"
        raise NotImplementedError()

    def delete(self, task_id: int):
        "Usuwa zadanie"
        raise NotImplementedError()

    def done(self, task_id: int):
        "Oznacza zadanie jako wykonane"
        raise NotImplementedError()
