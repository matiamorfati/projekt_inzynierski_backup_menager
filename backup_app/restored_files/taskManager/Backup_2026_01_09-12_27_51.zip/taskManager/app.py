from classes import Task
from datetime import date

tasks = []

def add_task():
    t = input("Tytuł: ").strip()
    if not t:
        print("Anulowano - brak tytułu.\n"); return
    d = input("Opis: ").strip()
    try:
        p = int(input("Priorytet (1-3): ").strip())
    except:
        print("Priorytet niepoprawny.\n"); return
    if p < 1 or p > 3:
        print("Priorytet 1-3.\n"); return
    tasks.append(Task(t, d, p, "todo", date.today()))
    print("OK - zadanie dodane.\n")

def list_tasks():
    if not tasks:
        print("Brak zadań.\n"); return
    for i, x in enumerate(tasks, 1):
        print(f"{i}. {x.title}")
        print("   Opis:", x.description)
        print("   Status:", x.status, "| Priorytet:", x.priority)
        print()

def edit_task():
    list_tasks()
    if not tasks: return
    try:
        i = int(input("Numer do edycji: ").strip())-1
    except:
        print("Niepoprawny numer.\n"); return
    if i<0 or i>=len(tasks): print("Nie ma takiego.\n"); return
    x = tasks[i]
    nt = input(f"Tytuł [{x.title}]: ").strip() or x.title
    nd = input(f"Opis [{x.description}]: ").strip() or x.description
    try:
        np_raw = input(f"Priorytet [{x.priority}]: ").strip()
        np = int(np_raw) if np_raw else x.priority
    except:
        print("Priorytet niepoprawny.\n"); return
    ns = input(f"Status [{x.status}]: ").strip() or x.status
    try:
        x.update(nt, nd, np, ns, x.due_date)
    except NotImplementedError:
        x.title, x.description, x.priority, x.status = nt, nd, np, ns
    print("Zrobione.\n")

def delete_task():
    list_tasks()
    if not tasks: return
    try:
        i = int(input("Numer do usunięcia: ").strip())-1
    except:
        print("Niepoprawny numer.\n"); return
    if 0 <= i < len(tasks):
        tasks.pop(i); print("Usunięto.\n")
    else:
        print("Nie ma takiego.\n")

def mark_done():
    list_tasks()
    if not tasks: return
    try:
        i = int(input("Numer do oznaczenia jako wykonane: ").strip())-1
    except:
        print("Niepoprawny numer.\n"); return
    if 0 <= i < len(tasks):
        try:
            tasks[i].mark_done()
        except NotImplementedError:
            tasks[i].status = "done"
        print("Oznaczono.\n")
    else:
        print("Nie ma takiego.\n")

def main():
    while True:
        print("1.Add 2.List 3.Edit 4.Del 5.Done 6.Exit")
        c = input("Wybierz: ").strip()
        if c=="1": add_task()
        elif c=="2": list_tasks()
        elif c=="3": edit_task()
        elif c=="4": delete_task()
        elif c=="5": mark_done()
        elif c=="6":
            print("Koniec"); break
        else:
            print("Niepoprawne.\n")

if __name__=="__main__":
    main()
