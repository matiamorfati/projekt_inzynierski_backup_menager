
import unittest
from datetime import date, timedelta

#Import klas które tetsujemy
from classes import (
    Task,
    TaskValidator,
    TaskRepository,
    TaskService,
    WebController,
)


class TaskTests(unittest.TestCase):
    
    def test_mark_done_changes_status(self):
    #test sprawdza czy metoda mark_done() zmienia status na "done"
    #na tent moment test failuje, bo metoda jest pusta
        task = Task(
            title="Test zadanie",
            description="Opis",
            priority=1,
            status="todo",
            due_date=date.today()
        )

        task.mark_done()   

    def test_update_changes_fields(self):
    #test sprawdza czy metoda update() poprawnie nadpisuje wszystkie pola zadania.
    #Na razie failuje, bo metoda jest pusta
        task = Task(
            title="Stare",
            description="Opis",
            priority=1,
            status="todo",
            due_date=date.today()
        )

        task.update(
            title="Nowe",
            description="Nowy opis",
            priority=2,
            status="doing",
            due_date=date.today() + timedelta(days=1)
        )


class TaskValidatorTests(unittest.TestCase):
    def test_validate_title_empty(self):
        #Test sprawdza czy walidator wykryje pusty tytul.
        #Metoda niezaimplemetowana wiec failuje.
        TaskValidator.validate_title("")

    def test_validate_priority_invalid(self):
        #Test sprawdza czy walidator odrzuci niepoprawny priorytet.
        #Na razie metoda pusta wiec fail.
        TaskValidator.validate_priority(999)

    def test_validate_due_date_past(self):
        #Test sprawdza czy walidator odrzuci date z przeszlosci
        #Metoda niezaimplmentowana wiec fail
        yesterday = date.today() - timedelta(days=1)
        TaskValidator.validate_due_date(yesterday)


class TaskServiceTests(unittest.TestCase):
    def test_create_task(self):
        #Test sprawdza czy serwis potrafi utworzyc nowe zadanie na podstwie przekazanych danych
        #Na razie test failuje
        service = TaskService()
        data = {
            "title": "Nowe",
            "description": "Opis",
            "priority": 1,
            "status": "todo",
            "due_date": date.today()
        }

        service.create_task(data)


class TaskRepositoryTests(unittest.TestCase):
    def test_add_get_task(self):
        #test sprawdza dodanie zadania i pobranie go z rezpozytorium
        #Na razie failuje bo rezpozytorium jest puste
        repo = TaskRepository()
        task = Task(
            title="Repo test",
            description="Opis",
            priority=1,
            status="todo",
            due_date=date.today()
        )

        repo.add(task)
        repo.get(1)


class WebControllerTests(unittest.TestCase):
    def test_index(self):
        #test sprawdza czy metoda index() potrafi obsluzyc wyswietlenie listy zadan
        #Na razie kontroler jest pusty wiec failuje.
        controller = WebController()
        controller.index()


#uruchomienie testow
if __name__ == "__main__":
    unittest.main()
